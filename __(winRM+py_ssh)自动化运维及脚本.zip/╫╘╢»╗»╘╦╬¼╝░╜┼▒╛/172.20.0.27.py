import paramiko

# SSH 连接信息
hostname = '172.20.0.27'  # Linux 系统的 IP 地址或主机名
port = 22                 # SSH 端口，默认是 22
username = 'admin'  # Linux 用户名
password = '2023PTSH!@#$'  # Linux 用户密码

# 创建 SSH 客户端
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

try:
    # 连接到 Linux 系统
    client.connect(hostname, port, username, password)

    # 执行命令
    stdin, stdout, stderr = client.exec_command("ifconfig")

    # 获取命令输出
    output = stdout.read().decode()
    error = stderr.read().decode()

    print("Output:")
    print(output)
    if error:
        print("Error:")
        print(error)

finally:
    # 关闭连接
    client.close()
