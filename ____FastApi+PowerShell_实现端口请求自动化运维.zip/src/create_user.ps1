﻿param (
    [string]$UserName,
    [string]$Password,
    [string]$FirstName,
    [string]$LastName,
    [string]$OU 
)

try {
    # 定义用户属性
    $userPrincipalName = "$UserName@example.com"  # 根据需要修改域名

    # 创建用户对象
    New-ADUser -Name "$FirstName $LastName" `
               -GivenName $FirstName `
               -Surname $LastName `
               -SamAccountName $UserName `
               -UserPrincipalName $userPrincipalName `
               -Path $OU `
               -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) `
               -PasswordNeverExpires $true `
               -Enabled $true

    Write-Output "User $UserName has been created successfully."
}
catch {
    Write-Output "An error occurred: $_"
}
