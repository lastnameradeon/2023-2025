﻿param (
    [string]$UserName
)

try {
    # 获取指定用户的信息
    $user = Get-ADUser -Identity $UserName -Properties DisplayName, EmailAddress, Title, Department, LastLogonDate, DistinguishedName
    
    # 组织用户信息
    $userInfo = [PSCustomObject]@{
        Username       = $user.SamAccountName
        DisplayName    = $user.DisplayName
        EmailAddress   = $user.EmailAddress
        Title          = $user.Title
        Department     = $user.Department
        LastLogonDate  = $user.LastLogonDate
        OU             = ($user.DistinguishedName -split ",", 2)[1]  # 提取 OU 部分
    }

    # 转换为 JSON 输出
    $userInfo | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}
