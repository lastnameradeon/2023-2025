﻿param(
    [string]$username
)

try {
    # 检查用户是否存在
    $user = Get-ADUser -Identity $username
    if ($user) {
        # 禁用用户
        Disable-ADAccount -Identity $username
        Write-Output "$username has been successfully disabled (locked)."
    } else {
        Write-Output "User $username not found."
    }
}
catch {
    Write-Output "An error occurred: $_"
}
