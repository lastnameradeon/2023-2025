
import subprocess

command = [
    "powershell",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    "unlock_ad_user.ps1",
    "-userName", "yinjun"
]

# 执行 PowerShell 脚本
result = subprocess.run(command, capture_output=True, text=True)