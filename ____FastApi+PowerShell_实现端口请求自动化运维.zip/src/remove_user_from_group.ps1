﻿param (
    [string]$UserName,
    [string]$GroupName
)

try {
    $user = Get-ADUser -Identity $UserName -ErrorAction Stop
    $group = Get-ADGroup -Identity $GroupName -ErrorAction Stop

    if (Get-ADGroupMember -Identity $GroupName | Where-Object { $_.SamAccountName -eq $UserName }) {
        Remove-ADGroupMember -Identity $GroupName -Members $UserName -Confirm:$false
        Write-Output "User $UserName has been removed from $GroupName."
    } else {
        Write-Output "User $UserName is not a member of $GroupName."
    }
}
catch {
    Write-Output "An error occurred: $_"
}
