﻿param (
    [string]$UserName,
    [string]$GroupName
)

try {
    $user = Get-ADUser -Identity $UserName -ErrorAction Stop
    $group = Get-ADGroup -Identity $GroupName -ErrorAction Stop

    if (Get-ADGroupMember -Identity $GroupName | Where-Object { $_.SamAccountName -eq $UserName }) {
        Write-Output "User $UserName is already a member of $GroupName."
    } else {
        Add-ADGroupMember -Identity $GroupName -Members $UserName
        Write-Output "User $UserName has been added to $GroupName."
    }
}
catch {
    Write-Output "An error occurred: $_"
}
