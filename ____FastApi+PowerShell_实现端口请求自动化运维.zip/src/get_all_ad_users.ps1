﻿try {
    # 获取所有AD用户
    $users = Get-ADUser -Filter * | Select-Object -ExpandProperty Name

    # 输出结果
    $users | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}
