﻿param(
    [string]$userName
)

try {
    # 检查用户是否存在
    $user = Get-ADUser -Identity $userName
    if ($user) {
        # 解锁用户
        Unlock-ADAccount -Identity $userName
        Write-Output "$userName has been successfully unlocked."
    } else {
        Write-Output "User $userName not found."
    }
}
catch {
    Write-Output "An error occurred: $_"
}
