from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import subprocess
import json
from fastapi.middleware.cors import CORSMiddleware
import logging
from logging.handlers import RotatingFileHandler

# 配置日志文件
log_file_path = "C://Users//administrator.PTSH//Desktop//src//fastapi_app.log"  # 设置日志文件的路径
log_formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

# 创建日志处理程序，最多保留10MB文件，最多5个备份文件
file_handler = RotatingFileHandler(log_file_path, maxBytes=10*1024*1024, backupCount=5)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.INFO)

# 获取 FastAPI 的 logger 并添加文件处理器
logger = logging.getLogger("uvicorn.access")
logger.addHandler(file_handler)

app = FastAPI()

# 设置CORS策略
origins = [
    "http://172.20.100.254:8000",
    "http://localhost:8000",
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

class UserGroup(BaseModel):
    username: str
    groupname: str
@app.post("/add-user-to-group/")
def add_user_to_group(usergroup: UserGroup):
    try:
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "add_user_to_group.ps1",
            "-UserName", usergroup.username,
            "-GroupName", usergroup.groupname
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            return {"message": result.stdout.strip()}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/get-all-groups/")
def get_all_groups():
    try:
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_all_groups.ps1"
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            groups = json.loads(result.stdout.strip())
            return {"groups": groups}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/remove-user-from-group/")
def remove_user_from_group(usergroup: UserGroup):
    try:
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "remove_user_from_group.ps1",
            "-UserName", usergroup.username,
            "-GroupName", usergroup.groupname
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            return {"message": result.stdout.strip()}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class User(BaseModel):
    username: str
@app.post("/get-user-groups/")
def get_user_groups(user: User):
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_user_groups.ps1",
            "-UserName", user.username
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            # 解析 PowerShell 输出的JSON
            groups = json.loads(result.stdout.strip())
            return {"username": user.username, "groups": groups}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UserCreate(BaseModel):
    username: str
    password: str
    first_name: str
    last_name: str
    ou: str
@app.post("/create-user/")
def create_user(user: UserCreate):
    try:
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "create_user.ps1",
            "-UserName", user.username,
            "-Password", user.password,
            "-FirstName", user.first_name,
            "-LastName", user.last_name,
            "-OU", user.ou
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            return {"message": result.stdout.strip()}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UserRequest(BaseModel):
    username: str
@app.post("/get-user-info/")
def get_user_info(user: UserRequest):
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_user_info.ps1",
            "-UserName", user.username
        ]
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            # 解析 PowerShell 输出的 JSON
            user_info = json.loads(result.stdout.strip())
            return {"user_info": user_info}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UserRequest(BaseModel):
    username: str
@app.post("/disable-user/")
def disable_user(user: UserRequest):
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "disable_user.ps1",
            "-UserName", user.username
        ]
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            return {"message": result.stdout.strip()}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class UserRequest(BaseModel):
    username: str

@app.post("/remove-user-from-groups/")
def remove_user_from_groups(user: UserRequest):
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "remove_user_from_groups.ps1",
            "-UserName", user.username
        ]

        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            return {"message": result.stdout.strip()}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class UserRequest(BaseModel):
    username: str


# 定义POST路由，用于查询指定用户没有的组
@app.post("/get-user-missing-groups/")
def get_user_missing_groups(user: UserRequest):
    try:
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_user_missing_groups.ps1",
            "-UserName", user.username
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            missing_groups = json.loads(result.stdout.strip())
            return missing_groups
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get-all-ad-users/")
def get_all_ad_users():
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_all_ad_users.ps1"
        ]

        # 执行 PowerShell 脚本
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            # 解析 PowerShell 输出的 JSON
            users = json.loads(result.stdout.strip())
            return {"users": users}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get-all-users-and-groups/")
def get_all_users_and_groups():
    try:
        # 构建 PowerShell 命令
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "get_all_users_and_groups.ps1"
        ]

        # 执行 PowerShell 脚本
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            # 解析 PowerShell 输出的 JSON
            users_and_groups = json.loads(result.stdout.strip())
            return {"users_and_groups": users_and_groups}
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/unlock-user/")
def unlock_user(user: UserRequest):
    try:
        # 构建 PowerShell 命令，传递用户名参数
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "unlock_ad_user.ps1",
            "-userName", user.username
        ]

        # 执行 PowerShell 脚本
        result = subprocess.run(command, capture_output=True, text=True)

        # 检查 PowerShell 的执行结果
        if result.returncode == 0:
            output = result.stdout.strip()
            if "successfully unlocked" in output:
                return {"message": f"User {user.username} has been successfully unlocked."}
            elif "not found" in output:
                raise HTTPException(status_code=404, detail=f"User {user.username} not found.")
            else:
                raise HTTPException(status_code=400, detail=output)
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/lock-user/")
def lock_user(user: UserRequest):
    try:
        # 构建 PowerShell 命令，传递用户名参数
        command = [
            "powershell",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "lock_ad_user.ps1",
            "-username", user.username
        ]

        # 执行 PowerShell 脚本
        result = subprocess.run(command, capture_output=True, text=True)

        # 检查 PowerShell 的执行结果
        if result.returncode == 0:
            output = result.stdout.strip()
            if "successfully disabled" in output:
                return {"message": f"User {user.username} has been successfully disabled (locked)."}
            elif "not found" in output:
                raise HTTPException(status_code=404, detail=f"User {user.username} not found.")
            else:
                raise HTTPException(status_code=400, detail=output)
        else:
            raise HTTPException(status_code=400, detail=result.stderr.strip())

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


