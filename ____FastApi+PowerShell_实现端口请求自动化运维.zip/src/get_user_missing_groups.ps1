﻿param (
    [string]$UserName
)

try {
    # 获取所有组
    $allGroups = Get-ADGroup -Filter * | Select-Object -ExpandProperty Name

    # 获取指定用户的组列表
    $user = Get-ADUser -Identity $UserName -Properties MemberOf
    $userGroups = $user.MemberOf | ForEach-Object { (Get-ADGroup $_).Name }

    # 获取用户没有的组 (排除已加入的组)
    $missingGroups = $allGroups | Where-Object { $_ -notin $userGroups }

    # 使用正则表达式筛选包含中文字符的组
    $chineseGroups = $missingGroups | Where-Object { $_ -match '[\u4e00-\u9fa5]' }

    # 输出结果
    $chineseGroups | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}

