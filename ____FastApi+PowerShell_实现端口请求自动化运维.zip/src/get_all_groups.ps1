﻿try {
    # 获取所有AD组
    $groups = Get-ADGroup -Filter * | Select-Object Name, SamAccountName

    # 转换为 JSON 输出
    $groups | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}
