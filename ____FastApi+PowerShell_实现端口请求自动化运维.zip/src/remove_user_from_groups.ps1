﻿param (
    [string]$UserName
)

try {
    # 获取指定用户的组列表
    $user = Get-ADUser -Identity $UserName -Properties MemberOf
    $groups = $user.MemberOf

    foreach ($groupDN in $groups) {
        $group = Get-ADGroup -Identity $groupDN
        if ($group.Name -ne "Domain Users") {
            # 从组中删除用户
            Remove-ADGroupMember -Identity $group.Name -Members $UserName -Confirm:$false
        }
    }

    Write-Output "User $UserName has been removed from all groups except 'Domain Users'."
}
catch {
    Write-Output "An error occurred: $_"
}
