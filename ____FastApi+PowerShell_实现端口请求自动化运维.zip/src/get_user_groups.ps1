﻿param (
    [string]$UserName
)

try {
    # 获取指定用户对象
    $user = Get-ADUser -Identity $UserName -ErrorAction Stop
    
    # 获取用户所属的所有组
    $groups = Get-ADUser -Identity $UserName -Properties MemberOf | Select-Object -ExpandProperty MemberOf
    
    # 解析组的DN名称
    $groupNames = @()
    foreach ($group in $groups) {
        $groupName = (Get-ADGroup -Identity $group).Name
        $groupNames += $groupName
    }
    
    # 转换为 JSON 输出
    $groupNames | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}
