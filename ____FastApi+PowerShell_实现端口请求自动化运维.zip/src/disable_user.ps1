﻿param (
    [string]$UserName
)

try {
    # 获取指定用户对象
    $user = Get-ADUser -Identity $UserName -ErrorAction Stop
    
    # 停用用户账户
    Disable-ADAccount -Identity $UserName
    
    Write-Output "User $UserName has been disabled successfully."
}
catch {
    Write-Output "An error occurred: $_"
}
