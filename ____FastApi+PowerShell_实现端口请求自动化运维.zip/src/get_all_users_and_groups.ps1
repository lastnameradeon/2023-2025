﻿try {
    # 获取所有AD组
    $allGroups = Get-ADGroup -Filter * | Select-Object -ExpandProperty Name

    # 创建正则表达式，匹配中文字符
    $chineseRegex = '[\u4e00-\u9fa5]'

    # 过滤掉不含中文字符的组
    $chineseGroups = $allGroups | Where-Object { $_ -match $chineseRegex }

    # 获取所有AD用户
    $users = Get-ADUser -Filter * -Property MemberOf | Select-Object Name, MemberOf

    # 创建结果列表
    $result = @()

    foreach ($user in $users) {
        # 获取用户已加入的组（如果为空，则返回空数组）
        $userGroups = if ($user.MemberOf) {
            $user.MemberOf | ForEach-Object { (Get-ADGroup $_).Name } | Where-Object { $_ -match $chineseRegex }
        } else {
            @()
        }

        # 计算用户未加入的组（仅包含中文组）
        $missingGroups = $chineseGroups | Where-Object { $_ -notin $userGroups }

        # 构建用户、已加入组和未加入组的对象
        $userObj = [PSCustomObject]@{
            UserName      = $user.Name
            Groups        = $userGroups
            MissingGroups = $missingGroups
        }

        # 添加到结果列表
        $result += $userObj
    }

    # 将结果转换为JSON输出
    $result | ConvertTo-Json
}
catch {
    Write-Output "An error occurred: $_"
}
